local mod = Abraha
local game = Game()

local dataholder = {}

dataholder.Data = {}
local Abraha = {}

function Abraha:AbrahaPostTearAte(tear)
    local player = tear.SpawnerEntity:ToPlayer()
    if player:GetPlayerType() == Isaac.GetPlayerTypeByName("Abraha", false) then
    tear.CollisionDamage = tear.CollisionDamage - 0.04*tear.CollisionDamag
    end
end

function Abraha:AbrahaPostTear(tear)
    local player = tear.SpawnerEntity:ToPlayer()
    if player:GetPlayerType() == Isaac.GetPlayerTypeByName("Abraha", false) then
    tear:AddTearFlags(TearFlags.TEAR_SPECTRAL | TearFlags.TEAR_PIERCING)
    end
end
mod:AddCallback(ModCallbacks.MC_POST_TEAR_UPDATE, Abraha.AbrahaPostTearAte)
mod:AddCallback(ModCallbacks.MC_POST_FIRE_TEAR, Abraha.AbrahaPostTear)